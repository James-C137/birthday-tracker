const { DynamoDBClient, BatchGetItemCommand } = require('@aws-sdk/client-dynamodb');

const REGION = "us-east-1";

exports.handler = async (event) => {
  const ddbClient = new DynamoDBClient({ region: REGION });
  const ddbResponse = await client.send(new BatchGetItemCommand());
  console.log(ddbResponse);

  const response = {
    statusCode: 200,
    body: JSON.stringify('Hello from Lambda!'),
  };
  return response;
};
